const API_BASE = 'http://localhost:4000/api';

async function request(path, { method = 'GET', body, token } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || 'Something went wrong. Please try again.');
  }

  return data;
}

export const api = {
  login: (email, password) => request('/auth/login', { method: 'POST', body: { email, password } }),
  register: (name, email, password) =>
    request('/auth/register', { method: 'POST', body: { name, email, password } }),
  getStock: (token) => request('/stock', { token }),
  setStock: (quantity, token) => request('/stock', { method: 'PUT', body: { quantity }, token }),
  createOrder: (quantity, note, token) =>
    request('/orders', { method: 'POST', body: { quantity, note }, token }),
  getMyOrders: (token) => request('/orders/mine', { token }),
  getAllOrders: (token) => request('/orders', { token }),
  acceptOrder: (id, token) => request(`/orders/${id}/accept`, { method: 'POST', token }),
  rejectOrder: (id, token) => request(`/orders/${id}/reject`, { method: 'POST', token }),
};
