import { useEffect, useState } from 'react';
import { api } from '../api';
import { useAuth } from '../context/AuthContext';

export default function AdminDashboard() {
  const { user, token, logout } = useAuth();
  const [stock, setStock] = useState(null);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionError, setActionError] = useState('');
  const [newStock, setNewStock] = useState('');

  async function loadData() {
    setLoading(true);
    try {
      const [stockData, orderData] = await Promise.all([
        api.getStock(token),
        api.getAllOrders(token),
      ]);
      setStock(stockData);
      setOrders(orderData);
    } catch (err) {
      setActionError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleAccept(id) {
    setActionError('');
    try {
      await api.acceptOrder(id, token);
      loadData();
    } catch (err) {
      setActionError(err.message);
    }
  }

  async function handleReject(id) {
    setActionError('');
    try {
      await api.rejectOrder(id, token);
      loadData();
    } catch (err) {
      setActionError(err.message);
    }
  }

  async function handleStockUpdate(e) {
    e.preventDefault();
    setActionError('');
    try {
      await api.setStock(Number(newStock), token);
      setNewStock('');
      loadData();
    } catch (err) {
      setActionError(err.message);
    }
  }

  const pending = orders.filter((o) => o.status === 'pending');
  const decided = orders.filter((o) => o.status !== 'pending');
  const capacityPct = stock ? Math.min(100, Math.round((stock.quantity / 200) * 100)) : 0;

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark">JK</span>
          <span>Chicken Care · Admin</span>
        </div>
        <div className="topbar-right">
          <span className="who">Hi, {user.name}</span>
          <button className="btn-ghost" onClick={logout}>Sign out</button>
        </div>
      </header>

      <main className="layout">
        <section className="panel gauge-panel">
          <h2 className="panel-title">Coop stock</h2>
          <div className="gauge">
            <div className="gauge-fill" style={{ height: `${capacityPct}%` }} />
            <div className="gauge-value">
              <strong>{loading ? '—' : stock?.quantity}</strong>
              <span>chickens available</span>
            </div>
          </div>
          <form onSubmit={handleStockUpdate} className="stock-update-form">
            <input
              type="number"
              min="0"
              placeholder="Set new total"
              value={newStock}
              onChange={(e) => setNewStock(e.target.value)}
              required
            />
            <button type="submit" className="btn-secondary">Update</button>
          </form>
        </section>

        <section className="panel wide">
          <h2 className="panel-title">Pending requests {pending.length > 0 && `(${pending.length})`}</h2>
          {actionError && <p className="form-error">{actionError}</p>}
          {loading ? (
            <p className="muted">Loading…</p>
          ) : pending.length === 0 ? (
            <p className="muted">No pending order requests right now.</p>
          ) : (
            <table className="order-table">
              <thead>
                <tr>
                  <th>Customer</th>
                  <th>Quantity</th>
                  <th>Note</th>
                  <th>Requested</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {pending.map((o) => (
                  <tr key={o.id}>
                    <td>{o.customer_name}<br /><span className="muted small">{o.customer_email}</span></td>
                    <td>{o.quantity}</td>
                    <td>{o.note || '—'}</td>
                    <td>{new Date(o.created_at).toLocaleString()}</td>
                    <td className="actions">
                      <button className="btn-accept" onClick={() => handleAccept(o.id)}>Accept</button>
                      <button className="btn-reject" onClick={() => handleReject(o.id)}>Reject</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>

        <section className="panel wide">
          <h2 className="panel-title">Order history</h2>
          {decided.length === 0 ? (
            <p className="muted">Decided orders will show up here.</p>
          ) : (
            <table className="order-table">
              <thead>
                <tr>
                  <th>Customer</th>
                  <th>Quantity</th>
                  <th>Status</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {decided.map((o) => (
                  <tr key={o.id}>
                    <td>{o.customer_name}</td>
                    <td>{o.quantity}</td>
                    <td><span className={`status status-${o.status}`}>{o.status}</span></td>
                    <td>{new Date(o.created_at).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      </main>
    </div>
  );
}
