import { useEffect, useState } from 'react';
import { api } from '../api';
import { useAuth } from '../context/AuthContext';

const STATUS_LABEL = {
  pending: 'Awaiting review',
  accepted: 'Accepted',
  rejected: 'Rejected',
};

export default function CustomerDashboard() {
  const { user, token, logout } = useAuth();
  const [stock, setStock] = useState(null);
  const [orders, setOrders] = useState([]);
  const [quantity, setQuantity] = useState('');
  const [note, setNote] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(true);

  async function loadData() {
    setLoading(true);
    try {
      const [stockData, orderData] = await Promise.all([
        api.getStock(token),
        api.getMyOrders(token),
      ]);
      setStock(stockData);
      setOrders(orderData);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setSuccess('');
    try {
      await api.createOrder(Number(quantity), note, token);
      setSuccess('Your order request has been sent for review.');
      setQuantity('');
      setNote('');
      loadData();
    } catch (err) {
      setError(err.message);
    }
  }

  const capacityPct = stock ? Math.min(100, Math.round((stock.quantity / 200) * 100)) : 0;

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark">JK</span>
          <span>Chicken Care</span>
        </div>
        <div className="topbar-right">
          <span className="who">Hi, {user.name}</span>
          <button className="btn-ghost" onClick={logout}>Sign out</button>
        </div>
      </header>

      <main className="layout">
        <section className="panel gauge-panel">
          <h2 className="panel-title">Coop stock</h2>
          <div className="gauge">
            <div className="gauge-fill" style={{ height: `${capacityPct}%` }} />
            <div className="gauge-value">
              <strong>{loading ? '—' : stock?.quantity}</strong>
              <span>chickens available</span>
            </div>
          </div>
          <p className="gauge-note">Stock updates the moment an order is accepted.</p>
        </section>

        <section className="panel">
          <h2 className="panel-title">Request an order</h2>
          <form onSubmit={handleSubmit} className="order-form">
            <label className="field">
              <span>How many chickens?</span>
              <input
                type="number"
                min="1"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                required
                placeholder="e.g. 10"
              />
            </label>
            <label className="field">
              <span>Note (optional)</span>
              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Preferred delivery date, breed, etc."
              />
            </label>
            {error && <p className="form-error">{error}</p>}
            {success && <p className="form-success">{success}</p>}
            <button type="submit" className="btn-primary">Send request</button>
          </form>
        </section>

        <section className="panel wide">
          <h2 className="panel-title">Your order history</h2>
          {loading ? (
            <p className="muted">Loading…</p>
          ) : orders.length === 0 ? (
            <p className="muted">No orders yet. Your first request will appear here.</p>
          ) : (
            <table className="order-table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Quantity</th>
                  <th>Note</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((o) => (
                  <tr key={o.id}>
                    <td>{new Date(o.created_at).toLocaleDateString()}</td>
                    <td>{o.quantity}</td>
                    <td>{o.note || '—'}</td>
                    <td>
                      <span className={`status status-${o.status}`}>
                        {STATUS_LABEL[o.status]}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      </main>
    </div>
  );
}
