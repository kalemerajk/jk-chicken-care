const express = require('express');
const db = require('../db');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// Get current stock (any logged-in user can see it)
router.get('/', authenticate, (req, res) => {
  const stock = db.prepare('SELECT quantity FROM stock WHERE id = 1').get();
  res.json(stock);
});

// Admin-only: update stock quantity directly (e.g. after a new delivery of chickens)
router.put('/', authenticate, requireAdmin, (req, res) => {
  const { quantity } = req.body;

  if (typeof quantity !== 'number' || quantity < 0) {
    return res.status(400).json({ error: 'Quantity must be a non-negative number' });
  }

  db.prepare('UPDATE stock SET quantity = ? WHERE id = 1').run(quantity);
  res.json({ quantity });
});

module.exports = router;
