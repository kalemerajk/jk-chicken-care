const express = require('express');
const db = require('../db');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// Customer: create a new order request
router.post('/', authenticate, (req, res) => {
  const { quantity, note } = req.body;

  if (!quantity || quantity <= 0) {
    return res.status(400).json({ error: 'Quantity must be a positive number' });
  }

  const result = db.prepare(
    'INSERT INTO orders (customer_id, quantity, note, status) VALUES (?, ?, ?, ?)'
  ).run(req.user.id, quantity, note || null, 'pending');

  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json(order);
});

// Customer: view their own orders
router.get('/mine', authenticate, (req, res) => {
  const orders = db.prepare(
    'SELECT * FROM orders WHERE customer_id = ? ORDER BY created_at DESC'
  ).all(req.user.id);
  res.json(orders);
});

// Admin: view all orders, with customer name joined in
router.get('/', authenticate, requireAdmin, (req, res) => {
  const orders = db.prepare(`
    SELECT orders.*, users.name AS customer_name, users.email AS customer_email
    FROM orders
    JOIN users ON users.id = orders.customer_id
    ORDER BY orders.created_at DESC
  `).all();
  res.json(orders);
});

// Admin: accept an order (only if enough stock is available; decrements stock)
router.post('/:id/accept', authenticate, requireAdmin, (req, res) => {
  const orderId = req.params.id;
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);

  if (!order) return res.status(404).json({ error: 'Order not found' });
  if (order.status !== 'pending') {
    return res.status(400).json({ error: `Order is already ${order.status}` });
  }

  const stock = db.prepare('SELECT quantity FROM stock WHERE id = 1').get();
  if (stock.quantity < order.quantity) {
    return res.status(400).json({
      error: `Not enough stock. Available: ${stock.quantity}, requested: ${order.quantity}`,
    });
  }

  // Run as a transaction so stock and order status stay in sync
  try {
    db.exec('BEGIN');
    db.prepare('UPDATE stock SET quantity = quantity - ? WHERE id = 1').run(order.quantity);
    db.prepare('UPDATE orders SET status = ? WHERE id = ?').run('accepted', orderId);
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    return res.status(500).json({ error: 'Failed to accept order. Please try again.' });
  }

  const updatedOrder = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  res.json(updatedOrder);
});

// Admin: reject an order
router.post('/:id/reject', authenticate, requireAdmin, (req, res) => {
  const orderId = req.params.id;
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);

  if (!order) return res.status(404).json({ error: 'Order not found' });
  if (order.status !== 'pending') {
    return res.status(400).json({ error: `Order is already ${order.status}` });
  }

  db.prepare('UPDATE orders SET status = ? WHERE id = ?').run('rejected', orderId);
  const updatedOrder = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  res.json(updatedOrder);
});

module.exports = router;
